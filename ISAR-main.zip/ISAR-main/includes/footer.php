<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2023 <a href="https://service.freewebsitecode.com">FreeWebsiteCode</a></strong>
    </div>
    <!-- /.container -->
</footer>